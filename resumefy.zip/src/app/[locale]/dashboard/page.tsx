import { useTranslations } from 'next-intl';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

export default function DashboardPage() {
  const t = useTranslations('home');
  
  return (
    <div className="min-h-screen flex flex-col">
      <main className="flex-1 container py-10">
        <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
        
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle>Create New Resume</CardTitle>
              <CardDescription>
                Upload your data and create a new resume
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/resume-builder">
                <Button className="w-full">
                  {t('build')}
                </Button>
              </Link>
            </CardContent>
          </Card>
          
          {/* We can add more cards here for saved resumes, templates, etc. */}
        </div>
      </main>
    </div>
  );
} 