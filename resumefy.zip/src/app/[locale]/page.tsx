import { Header } from "@/components/layout/Header";
import { Button } from "@/components/ui/button";
import { SignInButton, SignedIn, SignedOut } from "@clerk/nextjs";
import { useTranslations } from "next-intl";
import Link from "next/link";

export default function HomePage() {
  const t = useTranslations("home");

  return (
    <div className="min-h-screen flex flex-col">
      <main className="flex-1 flex items-center justify-center">
        <div className="text-center max-w-3xl px-4">
          <h1 className="text-4xl font-bold mb-4">{t("title")}</h1>
          <p className="text-xl mb-8">
            {t("description")}
            teste
          </p>

          <div className="flex justify-center gap-4">
            <Link href="/dashboard">
              <Button size="lg" variant="outline" className="cursor-pointer hover:bg-gray-100 hover:text-gray-900">
                Go to Dashboard
              </Button>
            </Link>
            <Link href="/resume-builder">
              <Button size="lg" variant="outline" className="cursor-pointer hover:bg-gray-100 hover:text-gray-900">
                {t("build")}
              </Button>
            </Link>
          </div>
        </div>
      </main>
    </div>
  );
}
