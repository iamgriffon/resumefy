import { UserButton } from "@clerk/nextjs";
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import { Button } from "@/components/ui/button";

export function Header() {
  const t = useTranslations('home');
  
  return (
    <header className="border-b max-w-screen-2xl px-14 mx-auto border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 max-w-screen-2xl items-center justify-between">
        <div className="flex items-center gap-2">
          <Link 
            href="/"
            className="font-bold text-xl"
          >
            {t('title')}
          </Link>
        </div>
        
        <div className="flex items-center gap-2">
          <Link href="/dashboard">
            <Button variant="ghost">Dashboard</Button>
          </Link>
          <Link href="/resume-builder">
            <Button variant="ghost">Resume Builder</Button>
          </Link>
          {/* <UserButton afterSignOutUrl="/" /> */}
        </div>
      </div>
    </header>
  );
} 