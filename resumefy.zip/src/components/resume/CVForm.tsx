"use client";

import { useState } from "react";
import { useForm, useFieldArray, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  PlusCircle, 
  Trash2, 
  Download, 
  ChevronRight, 
  CalendarIcon,
  Briefcase,
  GraduationCap,
  Award,
  ListChecks,
  Info
} from "lucide-react";
import { cvFormSchema, CVFormType } from "./schemas";
import { useTranslations } from "use-intl";
import { generateResumePDF } from '@/lib/pdf-generator';
import type { ResumeData } from '@/lib/file-parser';
import { ResumePreviewer } from "@/components/resume/ResumePreviewer";
import { cn } from "../../lib/utils";

export function CVForm({
  initialData,
  onSubmit,
  submitLabel,
}: {
  initialData?: CVFormType;
  onSubmit?: (data: CVFormType) => void;
  submitLabel?: string;
}) {
  const t = useTranslations("resume");
  const [activeTab, setActiveTab] = useState("personal");
  
  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
    watch,
  } = useForm<CVFormType>({
    resolver: zodResolver(cvFormSchema),
    defaultValues: {
      personalInfo: {
        fullName: initialData?.personalInfo?.fullName || "",
        email: initialData?.personalInfo?.email || "",
        phone: initialData?.personalInfo?.phone || "",
        location: initialData?.personalInfo?.location || "",
        linkedIn: initialData?.personalInfo?.linkedIn || "",
        summary: initialData?.personalInfo?.summary || ""
      },
      education: initialData?.education || [],
      experience: initialData?.experience || [],
      skills: { skills: initialData?.skills?.skills || "" },
      certifications: initialData?.certifications || [],
      additionalInfo: initialData?.additionalInfo || ""
    }
  });

  const { 
    fields: educationFields, 
    append: appendEducation,
    remove: removeEducation
  } = useFieldArray({
    control,
    name: "education"
  });

  const { 
    fields: experienceFields, 
    append: appendExperience,
    remove: removeExperience 
  } = useFieldArray({
    control,
    name: "experience"
  });

  const { 
    fields: certificationFields, 
    append: appendCertification,
    remove: removeCertification
  } = useFieldArray({
    control,
    name: "certifications"
  });

  const [previewData, setPreviewData] = useState<ResumeData | null>(null);

  const submit = (data: CVFormType) => {
    if (onSubmit) {
      try {
        if (submitLabel === "Confirm & Download") {
          generateResumePDF(data)
            .then(pdf => {
              pdf.save(`${data.personalInfo?.fullName || 'resume'}.pdf`);
              onSubmit(data);
            })
            .catch(err => {
              console.error('Failed to generate PDF:', err);
              onSubmit(data);
            });
        } else {
          onSubmit(data);
        }
      } catch (error) {
        console.error('Error in form submission:', error);
        onSubmit(data);
      }
    }
  };

  return (
    <div className="w-full">
      <div className="rounded-lg border border-border bg-card p-6 shadow-sm">
        <h2 className="text-2xl font-semibold text-card-foreground mb-4">Personal Information</h2>
        <form onSubmit={handleSubmit(submit)} className="space-y-6">
          <Tabs defaultValue="personal" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-6 mb-6">
              <TabsTrigger value="personal" className="flex items-center gap-2">
                <Info className="h-4 w-4" />
                <span className="hidden sm:inline">Personal</span>
              </TabsTrigger>
              <TabsTrigger value="experience" className="flex items-center gap-2">
                <Briefcase className="h-4 w-4" />
                <span className="hidden sm:inline">Experience</span>
              </TabsTrigger>
              <TabsTrigger value="education" className="flex items-center gap-2">
                <GraduationCap className="h-4 w-4" />
                <span className="hidden sm:inline">Education</span>
              </TabsTrigger>
              <TabsTrigger value="skills" className="flex items-center gap-2">
                <ListChecks className="h-4 w-4" />
                <span className="hidden sm:inline">Skills</span>
              </TabsTrigger>
              <TabsTrigger value="certifications" className="flex items-center gap-2">
                <Award className="h-4 w-4" />
                <span className="hidden sm:inline">Certifications</span>
              </TabsTrigger>
              <TabsTrigger value="additional" className="flex items-center gap-2">
                <Info className="h-4 w-4" />
                <span className="hidden sm:inline">Additional</span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="personal" className="space-y-4">
              <Card className="bg-card border-muted shadow-sm">
                <CardHeader className="pb-3">
                  <CardTitle>Personal Information</CardTitle>
                  <CardDescription>
                    Add your contact details and professional summary
                  </CardDescription>
                  <Separator className="mt-2" />
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Full Name</Label>
                      <Input
                        id="fullName"
                        {...register("personalInfo.fullName")}
                        placeholder="John Doe"
                        className={cn(
                          "w-full rounded-md border border-input bg-background px-3 py-2",
                          "text-sm text-foreground placeholder:text-muted-foreground",
                          "focus:outline-none focus:ring-2 focus:ring-ring"
                        )}
                      />
                      {errors.personalInfo?.fullName && (
                        <p className="text-sm text-destructive">{errors.personalInfo.fullName.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        {...register("personalInfo.email")}
                        type="email"
                        placeholder="john.doe@example.com"
                        className={cn(
                          "w-full rounded-md border border-input bg-background px-3 py-2",
                          "text-sm text-foreground placeholder:text-muted-foreground",
                          "focus:outline-none focus:ring-2 focus:ring-ring"
                        )}
                      />
                      {errors.personalInfo?.email && (
                        <p className="text-sm text-destructive">{errors.personalInfo.email.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone</Label>
                      <Input
                        id="phone"
                        {...register("personalInfo.phone")}
                        placeholder="+1 (555) 123-4567"
                        className={cn(
                          "w-full rounded-md border border-input bg-background px-3 py-2",
                          "text-sm text-foreground placeholder:text-muted-foreground",
                          "focus:outline-none focus:ring-2 focus:ring-ring"
                        )}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        {...register("personalInfo.location")}
                        placeholder="New York, NY"
                        className={cn(
                          "w-full rounded-md border border-input bg-background px-3 py-2",
                          "text-sm text-foreground placeholder:text-muted-foreground",
                          "focus:outline-none focus:ring-2 focus:ring-ring"
                        )}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="linkedIn">LinkedIn</Label>
                      <Input
                        id="linkedIn"
                        {...register("personalInfo.linkedIn")}
                        placeholder="https://linkedin.com/in/johndoe"
                        className={cn(
                          "w-full rounded-md border border-input bg-background px-3 py-2",
                          "text-sm text-foreground placeholder:text-muted-foreground",
                          "focus:outline-none focus:ring-2 focus:ring-ring"
                        )}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2 pt-2">
                    <Label htmlFor="summary">Professional Summary</Label>
                    <Textarea
                      id="summary"
                      {...register("personalInfo.summary")}
                      placeholder="A brief summary of your professional background and key strengths"
                      className={cn(
                        "w-full min-h-[120px] rounded-md border border-input bg-background px-3 py-2",
                        "text-sm text-foreground placeholder:text-muted-foreground",
                        "focus:outline-none focus:ring-2 focus:ring-ring"
                      )}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="experience" className="space-y-4">
              <Card className="bg-card border-muted shadow-sm">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Professional Experience</CardTitle>
                      <CardDescription>
                        Add your work history, starting with the most recent position
                      </CardDescription>
                    </div>
                    <Button
                      type="button"
                      onClick={() => appendExperience({ 
                        company: "", 
                        position: "", 
                        startDate: "", 
                        endDate: "", 
                        description: "" 
                      })}
                      variant="outline"
                      size="sm"
                      className="flex items-center gap-1"
                    >
                      <PlusCircle className="h-4 w-4" />
                      <span>Add</span>
                    </Button>
                  </div>
                  <Separator className="mt-2" />
                </CardHeader>
                <CardContent className="space-y-4">
                  {experienceFields.length === 0 ? (
                    <div className="text-center py-6 text-muted-foreground border border-dashed rounded-md">
                      No work experience added yet. Click "Add" to include your work history.
                    </div>
                  ) : (
                    experienceFields.map((field, index) => (
                      <Card key={field.id} className="bg-muted/30 relative group">
                        <Button 
                          type="button" 
                          variant="ghost" 
                          size="icon" 
                          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 text-destructive"
                          onClick={() => removeExperience(index)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                        <CardContent className="p-4 pt-6">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label htmlFor={`experience.${index}.company`}>Company</Label>
                              <Input
                                id={`experience.${index}.company`}
                                {...register(`experience.${index}.company` as const)}
                                placeholder="Company name"
                                className={cn(
                                  "w-full rounded-md border border-input bg-background px-3 py-2",
                                  "text-sm text-foreground placeholder:text-muted-foreground",
                                  "focus:outline-none focus:ring-2 focus:ring-ring"
                                )}
                              />
                              {errors.experience?.[index]?.company && (
                                <p className="text-sm text-destructive">{errors.experience[index]?.company?.message}</p>
                              )}
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor={`experience.${index}.position`}>Position</Label>
                              <Input
                                id={`experience.${index}.position`}
                                {...register(`experience.${index}.position` as const)}
                                placeholder="Job title"
                                className={cn(
                                  "w-full rounded-md border border-input bg-background px-3 py-2",
                                  "text-sm text-foreground placeholder:text-muted-foreground",
                                  "focus:outline-none focus:ring-2 focus:ring-ring"
                                )}
                              />
                              {errors.experience?.[index]?.position && (
                                <p className="text-sm text-destructive">{errors.experience[index]?.position?.message}</p>
                              )}
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor={`experience.${index}.startDate`}>Start Date</Label>
                              <div className="relative">
                                <Input
                                  id={`experience.${index}.startDate`}
                                  {...register(`experience.${index}.startDate` as const)}
                                  placeholder="YYYY-MM"
                                  className={cn(
                                    "w-full rounded-md border border-input bg-background px-3 py-2",
                                    "text-sm text-foreground placeholder:text-muted-foreground",
                                    "focus:outline-none focus:ring-2 focus:ring-ring"
                                  )}
                                />
                                <CalendarIcon className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                              </div>
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor={`experience.${index}.endDate`}>End Date</Label>
                              <div className="relative">
                                <Input
                                  id={`experience.${index}.endDate`}
                                  {...register(`experience.${index}.endDate` as const)}
                                  placeholder="YYYY-MM or Present"
                                  className={cn(
                                    "w-full rounded-md border border-input bg-background px-3 py-2",
                                    "text-sm text-foreground placeholder:text-muted-foreground",
                                    "focus:outline-none focus:ring-2 focus:ring-ring"
                                  )}
                                />
                                <CalendarIcon className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                              </div>
                            </div>
                          </div>
                          
                          <div className="space-y-2 mt-4">
                            <Label htmlFor={`experience.${index}.description`}>Description</Label>
                            <Textarea
                              id={`experience.${index}.description`}
                              {...register(`experience.${index}.description` as const)}
                              placeholder="Describe your responsibilities and achievements"
                              rows={4}
                              className={cn(
                                "w-full min-h-[120px] rounded-md border border-input bg-background px-3 py-2",
                                "text-sm text-foreground placeholder:text-muted-foreground",
                                "focus:outline-none focus:ring-2 focus:ring-ring"
                              )}
                            />
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="education" className="space-y-4">
              <Card className="bg-card border-muted shadow-sm">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Education</CardTitle>
                      <CardDescription>
                        Add your educational background
                      </CardDescription>
                    </div>
                    <Button
                      type="button"
                      onClick={() => appendEducation({ 
                        institution: "", 
                        degree: "", 
                        fieldOfStudy: "", 
                        startDate: "", 
                        endDate: "", 
                        description: "" 
                      })}
                      variant="outline"
                      size="sm"
                      className="flex items-center gap-1"
                    >
                      <PlusCircle className="h-4 w-4" />
                      <span>Add</span>
                    </Button>
                  </div>
                  <Separator className="mt-2" />
                </CardHeader>
                <CardContent className="space-y-4">
                  {educationFields.length === 0 ? (
                    <div className="text-center py-6 text-muted-foreground border border-dashed rounded-md">
                      No education added yet. Click "Add" to include your educational background.
                    </div>
                  ) : (
                    educationFields.map((field, index) => (
                      <Card key={field.id} className="bg-muted/30 relative group">
                        <Button 
                          type="button" 
                          variant="ghost" 
                          size="icon" 
                          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 text-destructive"
                          onClick={() => removeEducation(index)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                        <CardContent className="p-4 pt-6">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label htmlFor={`education.${index}.institution`}>Institution</Label>
                              <Input
                                id={`education.${index}.institution`}
                                {...register(`education.${index}.institution` as const)}
                                placeholder="University or school name"
                                className={cn(
                                  "w-full rounded-md border border-input bg-background px-3 py-2",
                                  "text-sm text-foreground placeholder:text-muted-foreground",
                                  "focus:outline-none focus:ring-2 focus:ring-ring"
                                )}
                              />
                              {errors.education?.[index]?.institution && (
                                <p className="text-sm text-destructive">{errors.education[index]?.institution?.message}</p>
                              )}
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor={`education.${index}.degree`}>Degree</Label>
                              <Input
                                id={`education.${index}.degree`}
                                {...register(`education.${index}.degree` as const)}
                                placeholder="Bachelor's, Master's, etc."
                                className={cn(
                                  "w-full rounded-md border border-input bg-background px-3 py-2",
                                  "text-sm text-foreground placeholder:text-muted-foreground",
                                  "focus:outline-none focus:ring-2 focus:ring-ring"
                                )}
                              />
                              {errors.education?.[index]?.degree && (
                                <p className="text-sm text-destructive">{errors.education[index]?.degree?.message}</p>
                              )}
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor={`education.${index}.fieldOfStudy`}>Field of Study</Label>
                              <Input
                                id={`education.${index}.fieldOfStudy`}
                                {...register(`education.${index}.fieldOfStudy` as const)}
                                placeholder="Major or concentration"
                                className={cn(
                                  "w-full rounded-md border border-input bg-background px-3 py-2",
                                  "text-sm text-foreground placeholder:text-muted-foreground",
                                  "focus:outline-none focus:ring-2 focus:ring-ring"
                                )}
                              />
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor={`education.${index}.startDate`}>Start Date</Label>
                              <div className="relative">
                                <Input
                                  id={`education.${index}.startDate`}
                                  {...register(`education.${index}.startDate` as const)}
                                  placeholder="YYYY-MM"
                                  className={cn(
                                    "w-full rounded-md border border-input bg-background px-3 py-2",
                                    "text-sm text-foreground placeholder:text-muted-foreground",
                                    "focus:outline-none focus:ring-2 focus:ring-ring"
                                  )}
                                />
                                <CalendarIcon className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                              </div>
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor={`education.${index}.endDate`}>End Date</Label>
                              <div className="relative">
                                <Input
                                  id={`education.${index}.endDate`}
                                  {...register(`education.${index}.endDate` as const)}
                                  placeholder="YYYY-MM or Present"
                                  className={cn(
                                    "w-full rounded-md border border-input bg-background px-3 py-2",
                                    "text-sm text-foreground placeholder:text-muted-foreground",
                                    "focus:outline-none focus:ring-2 focus:ring-ring"
                                  )}
                                />
                                <CalendarIcon className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                              </div>
                            </div>
                          </div>
                          
                          <div className="space-y-2 mt-4">
                            <Label htmlFor={`education.${index}.description`}>Description</Label>
                            <Textarea
                              id={`education.${index}.description`}
                              {...register(`education.${index}.description` as const)}
                              placeholder="Additional information about your studies"
                              rows={3}
                              className={cn(
                                "w-full min-h-[120px] rounded-md border border-input bg-background px-3 py-2",
                                "text-sm text-foreground placeholder:text-muted-foreground",
                                "focus:outline-none focus:ring-2 focus:ring-ring"
                              )}
                            />
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="skills" className="space-y-4">
              <Card className="bg-card border-muted shadow-sm">
                <CardHeader className="pb-3">
                  <CardTitle>Technical Skills</CardTitle>
                  <CardDescription>
                    List your skills separated by commas (e.g., JavaScript, React, Project Management)
                  </CardDescription>
                  <Separator className="mt-2" />
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Label htmlFor="skills">Skills</Label>
                    <Textarea
                      id="skills"
                      {...register("skills.skills")}
                      placeholder="JavaScript, TypeScript, React, Node.js, HTML, CSS, SQL..."
                      className={cn(
                        "h-40 w-full rounded-md border border-input bg-background px-3 py-2",
                        "text-sm text-foreground placeholder:text-muted-foreground",
                        "focus:outline-none focus:ring-2 focus:ring-ring"
                      )}
                    />
                    <div className="mt-4">
                      <p className="text-sm text-muted-foreground mb-2">Preview:</p>
                      <div className="flex flex-wrap gap-2">
                        {watch("skills.skills")?.split(',').map((skill: string, idx: number) => (
                          skill.trim() && (
                            <Badge 
                              key={idx} 
                              variant="secondary" 
                              className="bg-muted"
                            >
                              {skill.trim()}
                            </Badge>
                          )
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="certifications" className="space-y-4">
              <Card className="bg-card border-muted shadow-sm">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Certifications & Licenses</CardTitle>
                      <CardDescription>
                        Add your professional certifications and licenses
                      </CardDescription>
                    </div>
                    <Button
                      type="button"
                      onClick={() => appendCertification({
                        name: "",
                        issuer: "",
                        date: "",
                        expires: ""
                      })}
                      variant="outline"
                      size="sm"
                      className="flex items-center gap-1"
                    >
                      <PlusCircle className="h-4 w-4" />
                      <span>Add</span>
                    </Button>
                  </div>
                  <Separator className="mt-2" />
                </CardHeader>
                <CardContent className="space-y-4">
                  {certificationFields.length === 0 ? (
                    <div className="text-center py-6 text-muted-foreground border border-dashed rounded-md">
                      No certifications added yet. Click "Add" to include your certifications.
                    </div>
                  ) : (
                    certificationFields.map((field, index) => (
                      <Card key={field.id} className="bg-muted/30 relative group">
                        <Button 
                          type="button" 
                          variant="ghost" 
                          size="icon" 
                          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 text-destructive"
                          onClick={() => removeCertification(index)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                        <CardContent className="p-4 pt-6">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label htmlFor={`certifications.${index}.name`}>Certification Name</Label>
                              <Input
                                id={`certifications.${index}.name`}
                                {...register(`certifications.${index}.name` as const)}
                                placeholder="AWS Certified Solutions Architect"
                                className={cn(
                                  "w-full rounded-md border border-input bg-background px-3 py-2",
                                  "text-sm text-foreground placeholder:text-muted-foreground",
                                  "focus:outline-none focus:ring-2 focus:ring-ring"
                                )}
                              />
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor={`certifications.${index}.issuer`}>Issuing Organization</Label>
                              <Input
                                id={`certifications.${index}.issuer`}
                                {...register(`certifications.${index}.issuer` as const)}
                                placeholder="Amazon Web Services"
                                className={cn(
                                  "w-full rounded-md border border-input bg-background px-3 py-2",
                                  "text-sm text-foreground placeholder:text-muted-foreground",
                                  "focus:outline-none focus:ring-2 focus:ring-ring"
                                )}
                              />
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor={`certifications.${index}.date`}>Date Issued</Label>
                              <div className="relative">
                                <Input
                                  id={`certifications.${index}.date`}
                                  {...register(`certifications.${index}.date` as const)}
                                  placeholder="YYYY-MM"
                                  className={cn(
                                    "w-full rounded-md border border-input bg-background px-3 py-2",
                                    "text-sm text-foreground placeholder:text-muted-foreground",
                                    "focus:outline-none focus:ring-2 focus:ring-ring"
                                  )}
                                />
                                <CalendarIcon className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                              </div>
                            </div>
                            
                            <div className="space-y-2">
                              <Label htmlFor={`certifications.${index}.expires`}>Expiration Date (Optional)</Label>
                              <div className="relative">
                                <Input
                                  id={`certifications.${index}.expires`}
                                  {...register(`certifications.${index}.expires` as const)}
                                  placeholder="YYYY-MM or Never"
                                  className={cn(
                                    "w-full rounded-md border border-input bg-background px-3 py-2",
                                    "text-sm text-foreground placeholder:text-muted-foreground",
                                    "focus:outline-none focus:ring-2 focus:ring-ring"
                                  )}
                                />
                                <CalendarIcon className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="additional" className="space-y-4">
              <Card className="bg-card border-muted shadow-sm">
                <CardHeader className="pb-3">
                  <CardTitle>Additional Information</CardTitle>
                  <CardDescription>
                    Add any additional information you'd like to include
                  </CardDescription>
                  <Separator className="mt-2" />
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Label htmlFor="additionalInfo">Additional Information</Label>
                    <Textarea
                      id="additionalInfo"
                      {...register("additionalInfo")}
                      placeholder="Languages spoken, volunteer experience, relevant hobbies, etc."
                      className={cn(
                        "h-40 w-full rounded-md border border-input bg-background px-3 py-2",
                        "text-sm text-foreground placeholder:text-muted-foreground",
                        "focus:outline-none focus:ring-2 focus:ring-ring"
                      )}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button 
              type="button" 
              variant="outline"
              onClick={() => {
                if (activeTab === "personal") setActiveTab("experience");
                else if (activeTab === "experience") setActiveTab("education");
                else if (activeTab === "education") setActiveTab("skills");
                else if (activeTab === "skills") setActiveTab("certifications");
                else if (activeTab === "certifications") setActiveTab("additional");
                else if (activeTab === "additional") setActiveTab("personal");
              }}
              className="flex items-center gap-1"
            >
              Next
              <ChevronRight className="h-4 w-4" />
            </Button>
            <Button 
              type="submit" 
              className={cn(
                "flex items-center gap-1",
                "bg-primary text-primary-foreground hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-ring"
              )}
            >
              {submitLabel?.includes("Download") && <Download className="h-4 w-4" />}
              {submitLabel || "Save"}
            </Button>
          </div>

          {previewData && (
            <div id="resume-preview" style={{ position: 'absolute', left: '-9999px' }}>
              <ResumePreviewer data={previewData} />
            </div>
          )}
        </form>
      </div>
    </div>
  );
}
